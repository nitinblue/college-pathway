import streamlit as st
from sqlalchemy.orm import Session

from neuroconnections.app.db.session import SessionLocal
from neuroconnections.app.db.models import Journey, ExplorationStep, ActionItem
from neuroconnections.app.services.recommendation_service import recommend

st.set_page_config(page_title="NeuroConnections", layout="wide")
st.title("🧠 NeuroConnections")
st.caption("A guided exploration space — no pressure, no premature decisions")

db: Session = SessionLocal()

# -----------------------------
# Sidebar – Journey Selection
# -----------------------------
st.sidebar.header("Journey")

journeys = db.query(Journey).all()
journey_map = {f"{j.student_name} ({j.university})": j.id for j in journeys}

selected_journey_label = st.sidebar.selectbox(
    "Select existing journey",
    options=["Create New"] + list(journey_map.keys())
)

journey = None  # Default to None

if selected_journey_label == "Create New":
    st.sidebar.subheader("Create New Journey")
    student_name = st.sidebar.text_input("Student name")
    university = st.sidebar.selectbox("University", ["UIC", "PITT"])

    if st.sidebar.button("Create Journey"):
        journey = Journey(student_name=student_name, university=university)
        db.add(journey)
        db.commit()
        st.sidebar.success("Journey created. Refresh selection.")
        st.rerun()  # Use st.rerun() instead of st.stop() for Streamlit 1.28+ (refreshes without stopping)
else:
    journey_id = journey_map[selected_journey_label]
    journey = db.query(Journey).get(journey_id)

# Now check and render
if journey is None:
    st.warning("Please select or create a journey to continue.")
    st.stop()

# Main content (safe to access journey now)
st.subheader(f"Journey: {journey.student_name} – {journey.university}")

# -----------------------------
# Main – Journey Overview
# -----------------------------
st.subheader(f"Journey: {journey.student_name} – {journey.university}")

col1, col2 = st.columns([2, 1])

with col1:
    st.markdown("### Add Exploration Step")

    theme = st.selectbox(
        "Exploration Theme",
        ["Curiosity", "Skill", "Ethics", "Low Load"]
    )

    reflection = st.text_area(
        "Reflection (student’s thoughts, doubts, interests)",
        height=150,
        placeholder="What felt interesting? Confusing? Energizing?"
    )

    if st.button("Add Step"):
        step = ExplorationStep(
            theme=theme,
            reflection=reflection,
            journey_id=journey.id
        )
        db.add(step)
        db.flush()

        courses = recommend(theme, journey.university)
        for course in courses:
            db.add(
                ActionItem(
                    description=f"Explore course: {course}",
                    step_id=step.id
                )
            )

        db.commit()
        st.success("Exploration step added")
        st.rerun()  # Refresh the UI to show the new step

with col2:
    st.markdown("### Why This Matters")
    st.info(
        "- No decisions required\n"
        "- Reflection builds clarity\n"
        "- Actions stay small & reversible\n"
        "- History reduces anxiety"
    )

# -----------------------------
# History Timeline
# -----------------------------
st.markdown("---")
st.markdown("## 🕰️ Exploration History")

steps = (
    db.query(ExplorationStep)
    .filter_by(journey_id=journey.id)
    .order_by(ExplorationStep.id.desc())
    .all()
)

if not steps:
    st.write("No exploration steps yet.")
else:
    for step in steps:
        with st.expander(f"{step.theme} – Step #{step.id}", expanded=False):
            st.markdown("**Reflection**")
            st.write(step.reflection)

            st.markdown("**Action Items**")
            for action in step.actions:
                checked = st.checkbox(
                    action.description,
                    value=action.completed,
                    key=f"action_{action.id}"
                )
                if checked != action.completed:
                    action.completed = checked
                    db.commit()

# -----------------------------
# Footer
# -----------------------------
st.markdown("---")
st.caption(
    "NeuroExplorer is about exploration, not optimization. "
    "Clarity comes from motion, not certainty."
)
