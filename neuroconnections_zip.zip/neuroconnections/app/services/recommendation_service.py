from neuroconnections.app.seed.course_catalog import COURSE_CATALOG


def recommend(theme: str, university: str):
    catalog = COURSE_CATALOG.get(university, {})


    if theme == "Curiosity":
        return catalog.get("neuroscience_core", [])[:1]
    if theme == "Skill":
        return catalog.get("computational", [])[:1]
    if theme == "Ethics":
        return catalog.get("ethics", [])[:1]
    if theme == "Low Load":
        return catalog.get("low_load", [])


    return []