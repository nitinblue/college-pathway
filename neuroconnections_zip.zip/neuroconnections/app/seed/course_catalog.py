COURSE_CATALOG = {
    "UIC": {
    "neuroscience_core": [
    "BIOS 286 – Introductory Neuroscience",
    "BIOS 484 – Cellular Neurobiology",
    "PSCH 343 – Cognitive Psychology"
    ],
    "computational": [
    "CS 109 – Intro to Programming",
    "STAT 381 – Applied Statistics"
    ],
    "ethics": [
    "PHIL 215 – Bioethics",
    "PHIL 316 – Philosophy of Mind"
    ],
    "low_load": [
    "HNRS 202 – Honors Seminar",
    "ENTR 310 – Entrepreneurship"
    ]
    }
}